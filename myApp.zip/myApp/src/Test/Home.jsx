// Home.jsx
export default function Home() {
  return <h1>Welcome to Home Page</h1>;
}