export function Header() {

    return(
        <div>
            <header className="header">
                <h1>User Management System</h1>
            </header>
        </div>
    )
}