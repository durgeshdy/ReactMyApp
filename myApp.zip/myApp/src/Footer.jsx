function Footer() {
return(
    <div>
        <footer className="header">
            <p className="footer-class">Footer</p>
        </footer>
    </div>
)

}
export default Footer